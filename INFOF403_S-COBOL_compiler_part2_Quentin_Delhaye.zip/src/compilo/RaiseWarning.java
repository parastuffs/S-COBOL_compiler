package compilo;

/**
 * Write a warning message on the standard output.
 *
 */
public class RaiseWarning {

	
	public RaiseWarning(String message) {
		System.out.println("Warning Raised:\n\t"+message+"\n");
	}
}
